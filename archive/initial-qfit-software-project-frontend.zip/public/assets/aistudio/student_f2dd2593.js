/**
 * QFIT Student Portal Controller
 * Implements QR Scanner, Live Camera Stream, Demo Skip, Synced Workout Timer, and Waitlist.
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Authentication Check
  const authUser = window.QFitAuth ? window.QFitAuth.getCurrentUser() : null;
  const headerName = document.getElementById('student-header-name');
  const scannerMemberName = document.getElementById('scanner-member-name');
  const btnLogout = document.getElementById('btn-student-logout');

  const studentProfile = authUser ? {
    fullName: authUser.fullName,
    studentId: authUser.userIdentifier,
    faculty: authUser.faculty || 'Science & Technology',
    durationMinutes: 60
  } : {
    fullName: 'Alaena Sang',
    studentId: '620123456',
    faculty: 'Science & Technology',
    durationMinutes: 60
  };

  if (headerName) headerName.textContent = `👤 ${studentProfile.fullName}`;
  if (scannerMemberName) scannerMemberName.textContent = studentProfile.fullName;

  if (btnLogout) {
    btnLogout.addEventListener('click', () => {
      if (confirm('Sign out of QFIT Student Portal?')) {
        stopCamera();
        sessionStorage.removeItem('qfit_student_session_active');
        window.QFitAuth.logout();
      }
    });
  }

  // Views
  const viewScanner = document.getElementById('view-scanner');
  const viewTimer = document.getElementById('view-timer');
  const viewWaitlist = document.getElementById('view-waitlist');

  // Scanner elements
  const btnSkipScan = document.getElementById('btn-skip-scan');
  const btnTriggerCamera = document.getElementById('btn-trigger-camera');
  const btnRetryScan = document.getElementById('btn-retry-scan');
  const alertScanFailed = document.getElementById('alert-scan-failed');
  const scanFailReason = document.getElementById('scan-fail-reason');
  const scannerVideo = document.getElementById('scanner-video');
  const scannerPlaceholder = document.getElementById('scanner-placeholder');

  // Timer elements
  const timerStudentName = document.getElementById('timer-student-name');
  const timerStudentDetails = document.getElementById('timer-student-details');
  const studentCountdownText = document.getElementById('student-countdown-text');
  const studentTimerStatusText = document.getElementById('student-timer-status-text');
  const studentTimerCircle = document.getElementById('student-timer-circle');
  const alertTimerDesync = document.getElementById('alert-timer-desync');
  const btnStudentResync = document.getElementById('btn-student-resync');
  const alertQueueSuccess = document.getElementById('alert-queue-success');
  const btnCheckoutSession = document.getElementById('btn-checkout-session');

  // Waitlist elements
  const waitlistPosNumber = document.getElementById('waitlist-pos-number');
  const waitlistAheadText = document.getElementById('waitlist-ahead-text');
  const waitlistEstTime = document.getElementById('waitlist-est-time');
  const waitlistReadyBanner = document.getElementById('waitlist-ready-banner');
  const btnClaimSlot = document.getElementById('btn-claim-slot');
  const btnLeaveWaitlist = document.getElementById('btn-leave-waitlist');

  let currentActiveStudent = null;
  let timerInterval = null;
  let cameraStream = null;

  // 2. Initial State: Always show QR Scanner when arriving / signing in
  function evaluateCurrentState() {
    const isSessionActive = sessionStorage.getItem('qfit_student_session_active') === 'true';
    const queue = window.QFitStore.getQueue();
    const waitlist = window.QFitStore.getWaitlist();

    // If student explicitly scanned and joined during this session:
    if (isSessionActive) {
      const inQueue = queue.find(s => s.studentId === studentProfile.studentId);
      if (inQueue) {
        currentActiveStudent = inQueue;
        showActiveTimer(inQueue);
        return;
      }

      const inWait = waitlist.find(s => s.studentId === studentProfile.studentId);
      if (inWait) {
        showWaitlist(inWait);
        return;
      }
    }

    // Default upon signing in: Show QR Scanner Page
    showScanner();
  }

  function showScanner() {
    if (timerInterval) clearInterval(timerInterval);
    currentActiveStudent = null;
    sessionStorage.removeItem('qfit_student_session_active');

    viewScanner.style.display = 'block';
    viewTimer.style.display = 'none';
    viewWaitlist.style.display = 'none';
  }

  // 3. Camera Scanner & Live Stream Handling
  async function startCamera() {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        scannerVideo.srcObject = cameraStream;
        scannerVideo.style.display = 'block';
        scannerPlaceholder.style.display = 'none';

        btnTriggerCamera.textContent = '🟢 Camera Active - Scanning QR...';
        btnTriggerCamera.className = 'btn btn-success btn-block';

        // Simulate QR Code recognition after camera locks onto QR
        setTimeout(() => {
          stopCamera();
          processQueueEntry();
        }, 2200);
      } else {
        fallbackCameraScan();
      }
    } catch (err) {
      console.warn('Camera access not available or permission denied:', err);
      fallbackCameraScan();
    }
  }

  function fallbackCameraScan() {
    btnTriggerCamera.textContent = '📷 Scanning Entrance QR Code...';
    btnTriggerCamera.disabled = true;
    setTimeout(() => {
      btnTriggerCamera.textContent = '📸 Open Camera Scanner';
      btnTriggerCamera.disabled = false;
      processQueueEntry();
    }, 1200);
  }

  function stopCamera() {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      cameraStream = null;
    }
    if (scannerVideo) scannerVideo.style.display = 'none';
    if (scannerPlaceholder) scannerPlaceholder.style.display = 'flex';
    if (btnTriggerCamera) {
      btnTriggerCamera.textContent = '📸 Open Camera Scanner';
      btnTriggerCamera.className = 'btn btn-secondary btn-block';
      btnTriggerCamera.disabled = false;
    }
  }

  btnTriggerCamera.addEventListener('click', () => {
    startCamera();
  });

  // Skip feature for live demo (adds student to queue immediately)
  btnSkipScan.addEventListener('click', () => {
    stopCamera();
    processQueueEntry();
  });

  btnRetryScan.addEventListener('click', () => {
    window.QFitStore.setSimulateQueueFailure(false);
    processQueueEntry();
  });

  // 4. Process Queue Addition (F-01)
  function processQueueEntry() {
    alertScanFailed.style.display = 'none';

    const result = window.QFitStore.addStudent(studentProfile);

    if (result.success) {
      sessionStorage.setItem('qfit_student_session_active', 'true');

      if (result.status === 'active') {
        currentActiveStudent = result.student;
        alertQueueSuccess.style.display = 'flex';
        setTimeout(() => {
          alertQueueSuccess.style.display = 'none';
        }, 3500);
        showActiveTimer(result.student);
      } else if (result.status === 'waitlist') {
        showWaitlist(result.student);
      }
    } else {
      // Sync failed -> Prompt to rescan (F-01 SR-2, AC-2)
      scanFailReason.textContent = result.message || 'System failed to add you to the queue. Please scan the QR code again.';
      alertScanFailed.style.display = 'flex';
    }
  }

  // 5. Active Timer UI (F-02)
  function showActiveTimer(student) {
    if (timerInterval) clearInterval(timerInterval);
    stopCamera();

    viewScanner.style.display = 'none';
    viewWaitlist.style.display = 'none';
    viewTimer.style.display = 'block';

    timerStudentName.textContent = student.fullName;
    timerStudentDetails.textContent = `ID: ${student.studentId} • ${student.faculty}`;

    function tick() {
      const queue = window.QFitStore.getQueue();
      const updated = queue.find(s => s.id === student.id || s.studentId === student.studentId);

      if (!updated) {
        clearInterval(timerInterval);
        alert('You have been checked out of the gym. Thank you for your workout session!');
        showScanner();
        return;
      }

      // Check desync status (F-02 SR-3)
      if (updated.syncFailed) {
        alertTimerDesync.style.display = 'flex';
      } else {
        alertTimerDesync.style.display = 'none';
      }

      const elapsedMs = Date.now() - updated.joinedAt;
      const totalMs = updated.durationMinutes * 60 * 1000;
      const remainingMs = totalMs - elapsedMs;

      if (remainingMs > 0) {
        const totalSec = Math.floor(remainingMs / 1000);
        const mins = Math.floor(totalSec / 60);
        const secs = totalSec % 60;
        studentCountdownText.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

        if (mins < 5) {
          studentTimerCircle.className = 'student-timer-circle warning';
          studentTimerStatusText.textContent = 'Wrapping Up Soon';
        } else {
          studentTimerCircle.className = 'student-timer-circle';
          studentTimerStatusText.textContent = 'Time Remaining';
        }
      } else {
        // Expired (F-02 SR-2)
        const overtimeSec = Math.abs(Math.floor(remainingMs / 1000));
        const oMins = Math.floor(overtimeSec / 60);
        const oSecs = overtimeSec % 60;
        studentCountdownText.textContent = `-${String(oMins).padStart(2, '0')}:${String(oSecs).padStart(2, '0')}`;
        studentTimerCircle.className = 'student-timer-circle expired';
        studentTimerStatusText.textContent = 'SESSION EXPIRED';
      }
    }

    tick();
    timerInterval = setInterval(tick, 1000);
  }

  btnStudentResync.addEventListener('click', () => {
    if (currentActiveStudent) {
      window.QFitStore.resyncStudent(currentActiveStudent.studentId);
      alertTimerDesync.style.display = 'none';
      alert('Resync successful! Your timer is now aligned with the gym staff dashboard.');
    }
  });

  btnCheckoutSession.addEventListener('click', () => {
    if (confirm('Finish workout and check out of the gym?')) {
      if (currentActiveStudent) {
        window.QFitStore.removeStudent(currentActiveStudent.id);
      }
      showScanner();
    }
  });

  // 6. Waitlist UI Logic (Capacity = 20)
  function showWaitlist(entry) {
    if (timerInterval) clearInterval(timerInterval);
    stopCamera();

    viewScanner.style.display = 'none';
    viewTimer.style.display = 'none';
    viewWaitlist.style.display = 'block';

    const waitlist = window.QFitStore.getWaitlist();
    const pos = waitlist.findIndex(s => s.studentId === entry.studentId) + 1;
    const peopleAhead = Math.max(0, pos - 1);

    waitlistPosNumber.textContent = `#${pos || 1}`;
    waitlistAheadText.textContent = `${peopleAhead} ${peopleAhead === 1 ? 'person' : 'people'} ahead of you`;

    const queue = window.QFitStore.getQueue();
    let minWait = 10;
    if (queue.length > 0) {
      const remainingTimes = queue.map(s => {
        const rem = (s.durationMinutes * 60 * 1000) - (Date.now() - s.joinedAt);
        return Math.max(1, Math.round(rem / (60 * 1000)));
      });
      minWait = Math.min(...remainingTimes);
    }
    waitlistEstTime.textContent = `Estimated Wait: ~${minWait * pos} minutes`;

    const cap = window.QFitStore.getCapacityStatus();
    if (!cap.isFull && pos === 1) {
      waitlistReadyBanner.style.display = 'flex';
    } else {
      waitlistReadyBanner.style.display = 'none';
    }
  }

  btnClaimSlot.addEventListener('click', () => {
    const promoted = window.QFitStore.promoteFromWaitlist(studentProfile.studentId);
    if (promoted) {
      currentActiveStudent = promoted;
      showActiveTimer(promoted);
    } else {
      alert('Unable to enter right now. Please wait for an active slot.');
    }
  });

  btnLeaveWaitlist.addEventListener('click', () => {
    if (confirm('Cancel and leave the waitlist?')) {
      window.QFitStore.removeWaitlistEntry(studentProfile.studentId);
      showScanner();
    }
  });

  // 7. Store Subscription
  window.QFitStore.subscribe((event) => {
    if (event.type === 'SLOT_AVAILABLE' || event.type === 'STUDENT_REMOVED') {
      const waitlist = window.QFitStore.getWaitlist();
      const inWait = waitlist.find(s => s.studentId === studentProfile.studentId);
      if (inWait) {
        showWaitlist(inWait);
      }
    } else if (event.type === 'DEMO_RESET') {
      evaluateCurrentState();
    }
  });

  // Initial load
  evaluateCurrentState();
});
